# ZAO Bot — Implementation Prompt
> Use this document as a reference prompt when rebuilding ZAO's systems in another bot.
> It describes every command, security system, and panel feature precisely enough to reimplement them.

---

## PART 1 — COMMANDS

### Permission levels
- `0` = any user
- `1` = group admin (Facebook group admin role)
- `2` = bot admin (UID in `ADMINBOT` array in config)

### Command format
Each command is a JS module with:
```js
module.exports.config = { name, aliases, hasPermssion, commandCategory, usages, cooldowns }
module.exports.run = async function({ api, event, args, Users, Threads, Currencies, getText }) {}
```
Prefix is configurable (default `.`). Commands are loaded from `SCRIPTS/ZAO-CMDS/`.

---

### INFO & UTILITY COMMANDS

| Command | Aliases | Perm | Description |
|---------|---------|------|-------------|
| `ping` | وضع, status, حالة, pong, صحة | 0 | RTT latency check + memory, uptime, MQTT status, command count. Sends a quick pong first, then a detailed status card. |
| `معلومات` | — | 0 | Full bot info: UID, uptime, command count, thread count, bot name, prefix, admin count, active tier. |
| `احصائيات` | stats, systems, انظمة, نظام, sysinfo | 2 | Comprehensive system stats: cookies, all protection systems with intervals/settings, memory, MQTT, stealth engine state, motors, locks. Admin only. |
| `uptime` | — | 0 | Generates a canvas image (canvas npm) showing: CPU%, RAM, uptime formatted, system load. Uses Roboto fonts from `SCRIPTS/ZAO-CMDS/uptime/Roboto/`. |
| `uid` | id, getid | 0 | Returns Facebook UID of: yourself / mentioned user / replied-to user / manually entered UID. |
| `help` / `اوامر` | cmds, commands, أوامر, الاوامر, h | 0 | Lists command categories with emoji icons. User replies with a number to see commands in that category. Categories: إدارة البوت, إدارة المجموعة, نظام, أدوات, ألعاب, ترفيه, ذكاء اصطناعي, ميديا, معلومات. Shows command name + usage inline. |

---

### AI COMMANDS

| Command | Perm | Description |
|---------|------|-------------|
| `ai` | 0 | OpenRouter multi-model AI chat. Tries models in priority order (grok, gpt-4o-mini, deepseek-v3, gemma, etc.), falls back to next on failure. Supports: text questions, reply-to-image (vision), user identity lookup from `data/ai-users.json`. Tracks `_bestModelIdx` across calls. Arabic-first responses. |
| `sim` | 0 | SimSimi-style chitchat via external API. Requires `simsimiApiKey` in settings. Fallback response if API unreachable. |
| `شخصية` | 0 | Personality chat — assigns the bot a persona (e.g. "أنت صديق مضحك"). Persona persists per-thread until reset. Uses AI backend. |
| `اصنع` | 0 | AI image generation — takes a text prompt and calls an image generation API (configurable in settings). Returns image attachment. |
| `imgen` | 0 | Same as اصنع (alias for English users). |

---

### GROUP MANAGEMENT COMMANDS (Perm 1–2)

| Command | Aliases | Perm | Description |
|---------|---------|------|-------------|
| `ban` | حظر | 1 | Ban/unban members in a group. Subcommands: `ban [@mention/reply/uid] [reason]`, `ban unban [@mention/reply/uid]`, `ban list`, `ban check` (kick currently banned members). State stored in `data/ban.json`. |
| `kick` | طرد | 1 | Remove one or more members. Supports: @mention, reply-to-message, multiple mentions at once. Checks bot-is-not-self before kicking. |
| `warn` | — | 1 | Warn a member. After `MAX_WARNS` (3) warnings, auto-kick. Subcommands: `warn [@user] [reason]`, `warn remove [@user]`, `warn list`. State in `data/warn.json`. |
| `gcadmin` | مشرف, admin-gc | 1 | Promote/demote group admins via MQTT. Usage: `مشرف [@tag/uid/reply]` to promote, `مشرف إلغاء` to demote. |
| `lockdown` | ld, autoadd, lock | 2 | Auto-readd members who leave the group. Subcommands: `lockdown on`, `lockdown off`, `lockdown status`. State in `data/autoinvite_settings.json`. |
| `antiout` | — | 2 | Prevent members from leaving: if someone leaves and `antiout` is enabled, re-add them immediately. Works via `leave` event handler. |
| `out` | — | 2 | Make the bot leave a specific group. Usage: `out [threadID]` or run in the target group. |
| `ضيفني` | — | 0 | Ask the bot to add you to a group. Bot must be admin. Requires the bot to be in the target group. |
| `groupname` | — | 1 | Change the group name. Usage: `groupname [new name]`. |
| `pinmsg` | — | 1 | Pin a message in the group (replies required). Uses `api.pinMessage`. |
| `pin` | — | 1 | Toggle pin status. |
| `poll` | — | 0 | Create a group poll. Usage: `poll [question] / [option1] / [option2] ...` |
| `عد` | — | 1 | Count group members / online members. |
| `badwords` | — | 2 | Manage auto-delete bad words list. Subcommands: `badwords add [word]`, `badwords remove [word]`, `badwords list`, `badwords on/off`. |
| `تنظيف` | — | 2 | Bulk delete recent bot messages in group (cleanup). |
| `صامت` | — | 2 | Silence mode — bot ignores all non-admin messages in this group for N minutes. |
| `بحث_عضو` | — | 1 | Search group members by name fragment. Returns matching UIDs + display names. |

---

### NICKNAME SYSTEM (Perm 1–2)

| Command | Description |
|---------|-------------|
| `كنيات` (nicknames) | Full nickname lock system. Subcommands: `تشغيل [template]` — lock everyone with a template (supports `{name}`, `{index}` placeholders), `بوت [nick]` — lock bot's own nickname, `ايقاف` — remove all group locks, `تنظيف` — clear all nicknames, `حالة` — show lock status, `قائمة` — list all locked groups, `قفل [nick]` (reply) — lock one user's nickname individually (user lock overrides group lock), `فك` (reply) — release individual user lock, `مقفولون` — list individually locked members. Priority: User Lock > Group Lock > Normal. Re-enforces every 60 seconds. |
| `nm` | Group name rotation lock. Lock the group name and rotate it on a timer. Usage: `nm [name]`, `nm off`, `nm random [range]` (e.g. `6s-30s` or `1m-5m`). Uses `nameLocks.js` for persistence. |
| `protect` / `حماية` | Nickname protection. Saves current nicknames, reverts any change made by non-admins. Subcommands: `protect on/off`, `protect set @user nick`, `protect list`. |

---

### BOT ADMIN COMMANDS (Perm 2)

| Command | Description |
|---------|-------------|
| `shutdown` | Sends SIGTERM to parent process (Main.js) → graceful bot shutdown. Fallback: `process.exit(0)`. |
| `rest` / `refresh` | Restart the bot child process via IPC signal to Main.js. |
| `cookieupdate` / `كوكيز` | Save current live AppState to `ZAO-STATE.json` + `alt.json` immediately (manual backup). |
| `setaccount` | Switch active Facebook tier (1–5). Updates `data/active-tier.json` and triggers reconnect. |
| `snapshot` | Create a version snapshot of key bot files. Stored in `panel/smart-versions.json` and viewable from the panel Smart Deploy page. Usage: `snapshot [label]`, `snapshot list`. |
| `antdetect` | View/manage anti-detection settings. Subcommands: `status` (current UA, presence, rate limit stats), `settings`, `ua` (current user-agent), `presence`. Perm 2. |
| `engine` | Motor 1 — group name rotation. Start/stop/status a per-thread name-change loop with configurable interval (random range in seconds or minutes). |
| `motor2` | Motor 2 — group image rotation. Same loop concept but changes group photo. |
| `صورة` | Combined image lock: set a custom group image and lock it (auto-restore if changed by others). |
| `presence` | Control the bot's online/typing/offline presence. Subcommands: `on/off`, `status`. |
| `بروفايل` | Change bot's profile picture. Reply to a photo with `.بروفايل`. |
| `cp` | Master control panel command. Manages: nameLocks, nicknameLocks, groupImgLocks, nickProtect — all in one interface. Also handles typed log events. |
| `e2ee` | E2EE management. Subcommands: `status`, `bundle`, `handshake <msg>`, `send <msg>`, `pinmsg <msg>`, `pin set/clear [pin]`, `autoencrypt on/off`, `verify`, `selftest`, `diagnose`, `drop`, `list`, `import <bundle>`. |
| `احصائيات` | Full system stats (described in INFO section above). |

---

### ENTERTAINMENT & TOOLS

| Command | Aliases | Perm | Description |
|---------|---------|------|-------------|
| `8ball` | — | 0 | Magic 8-ball fortune. Random answer from a predefined list. |
| `slot` | — | 0 | Slot machine game. |
| `xo` | — | 0 | Tic-tac-toe with the bot (or another player via mention). |
| `guess` | — | 0 | Number guessing game. |
| `truth` / `حقيقة` | — | 0 | Truth or dare — sends a random truth question. |
| `صواب_خطأ` | — | 0 | True/False trivia. |
| `pair` | — | 0 | Randomly "pairs" two group members. |
| `نرد` | — | 0 | Roll a dice. |
| `حظ` | — | 0 | Daily luck score (1-100). |
| `تقييم` | — | 0 | Rate something (sends a random score). |
| `mood` | — | 0 | Random mood/emotion generator. |
| `angel` | — | 0 | Angel/devil personality quiz. |
| `flags` | — | 0 | Country flag quiz — guess the country from the flag emoji. |
| `Shindo` | — | 0 | Shindo Life (Roblox) game info / random spin. |
| `ثنائي` | — | 0 | Binary converter (text ↔ binary). |
| `هاش` | — | 0 | Hash generator (MD5/SHA256). |
| `كلمة_سر` | — | 0 | Random strong password generator. |
| `كتلة_جسم` | — | 0 | BMI calculator. |
| `حاسبة` | calc, calculate, math | 0 | Safe math expression evaluator (no eval injection — uses whitelisted chars). |
| `قصر` | — | 0 | URL shortener. |
| `مؤقت` | — | 0 | Set a timer; bot mentions you when time is up. |
| `remind` | — | 0 | Reminder system. Usage: `remind [time] [message]`. |
| `كلمة` | — | 0 | Word of the day / random Arabic word. |
| `divel` | — | 0 | Divider/separator line generator. |
| `tempmail` | — | 0 | Generate a temporary email address via external API. |
| `qrgen` | — | 0 | Generate QR code from text/URL. Returns as image attachment. |
| `عشوائي` | — | 0 | Random number in a given range. |
| `نكرار` | — | 0 | Repeated character art / repeat message N times. |
| `صدى` | — | 0 | Echo — bot repeats what you say. |
| `تست` | — | 0 | Quick test/echo command for debugging. |

---

### MEDIA & DOWNLOAD

| Command | Aliases | Perm | Description |
|---------|---------|------|-------------|
| `song` | — | 0 | Download a song from YouTube by name/URL. Returns audio attachment. |
| `tiktok` | — | 0 | Download TikTok video (no watermark). |
| `جلب` | — | 0 | Download/fetch media from a URL. |
| `pp` | — | 0 | Fetch Facebook profile picture of a user (by UID or mention). |
| `translate` / `ترجم` | trans, dich, tr | 0 | Translate text to any language using LibreTranslate or Google Translate proxy. Usage: `ترجم [text] -> [lang_code]`. Defaults to Arabic if no target specified. Reply to a message to translate it. |
| `طقس_مدينة` | weather, طقس, جو | 0 | Weather for any city via wttr.in (no API key required). |
| `عملة` | — | 0 | Currency conversion via public exchange rate API. |
| `تاريخ` | — | 0 | Today's date in Hijri + Gregorian. |

---

### INSTAGRAM BOT COMMANDS (`SCRIPTS/INSTA-CMDS/`)

| Command | Description |
|---------|-------------|
| `!ping` | Latency + status check. |
| `!help` | List available Instagram commands. |
| `!info` | Bot info (username, uptime, version). |
| `!احصائيات` | Instagram session stats. |
| `!ai` | AI chat via OpenRouter (same models as Facebook bot). |
| `!nm` | Group name control for Instagram threads. |
| `!slot` / `!نرد` / etc. | Entertainment commands mirrored from Facebook bot. |
| `!ترجم` / `!حاسبة` / `!طقس` / `!تاريخ` / `!حظ` / `!تقييم` / `!حقيقة` / `!ثنائي` / `!شخصية` / `!عشوائي` / `!معرف` / `!هاش` / `!صدى` / `!محرك` / `!محرك2` / `!كرة8` | Full Arabic command set mirrored on Instagram. |

---

## PART 2 — SECURITY SYSTEMS

### 2A — Anti-Suspension Engine (`includes/antiSuspension.js`)
- Human typing simulation: random delay between `minDelay`–`maxDelay` ms (config-driven), scaled by `charsPerSecond` and message length
- Night mode: delay multiplier applied between 22:00–06:00 UTC (`nightModeMultiplier`)
- Thinking pauses: random chance (`thinkingPauseChance`) to insert an extra pause mid-typing simulation
- Read receipt randomization: sends "seen" with jitter instead of instantly
- User-agent rotation: pool of real Chrome/Firefox/Safari UA strings; rotates on each HTTP-based API call
- Online presence cycling: HEAD-pings facebook.com on a random interval (30–120 min) with rotating UA

### 2B — Anti-Spam / Rate Limiter (`includes/EnhancedRateLimiter.js`)
- Per-thread and per-user message rate limits
- Global queue size cap
- Burst detection: if a thread sends too many messages in a short window, all further messages from that thread are queued with delay
- Auto-lock integration: if non-admin command attempts exceed `maxCommands` within `windowSeconds`, bot auto-locks (admins always bypass); configurable `unlockAfterMinutes` or manual unlock via panel

### 2C — MQTT Health Watchdog (`includes/mqttHealthCheck.js`)
- Monitors MQTT silence: if no messages received in `silentTimeoutMinutes` (default 10), triggers reconnect
- Check interval is randomized between `checkIntervalMinMinutes`–`checkIntervalMaxMinutes` (default 2–5 min) to avoid detectable patterns
- Exponential backoff on restart failures (`backoffMultiplier`, `maxBackoffMinutes`)
- `maxRestarts` limit before giving up and alerting admins
- Optional Telegram/Discord webhook notification on session error (`notiWhenListenMqttError`)

### 2D — Session Guard (`includes/sessionGuard.js`)
- Periodically validates the active Facebook session by attempting a lightweight API call
- On failure: triggers cookie re-save, logs warning, optionally restarts bot
- Cookie snapshots stored in `backups/` directory

### 2E — E2EE / Labyrinth (`includes/labyrinth/Labyrinth.js`)
- Signal Protocol: X3DH key exchange + Double Ratchet for forward secrecy
- Wire format: `🔐ZAO|<base64-encoded-JSON>` (Signal) or `🔒E2EE:<base64>` (Legacy Liberty)
- PIN passive mode: fallback AES-256 encryption using a PIN-derived key (for users who haven't done X3DH handshake)
- `autoencrypt` mode: all outgoing messages in a session are automatically encrypted
- Session state stored in `data/labyrinth-{threadID}.json`
- Commands: `bundle` (share public key), `handshake`, `send`, `verify`, `selftest`, `diagnose`, `drop` (end session)

### 2F — React-to-Unsend (`reactUnsend`)
- Configured in `ZAO-SETTINGS.json`: `reactUnsend.enable`, `onlyAdmin`, `emojis` (default `["😡","😠"]`)
- If a bot admin reacts with one of the configured emojis to any bot message, that message is immediately unsent
- Protects against accidental sensitive outputs

### 2G — Whitelist Mode
- `whiteListMode`: if enabled, only UIDs in `whiteListIds` can use the bot
- `whiteListModeThread`: if enabled, only threads in `whiteListThreadIds` receive responses
- Both configurable via panel → Settings tab

### 2H — Bad Words Filter
- `badwords` command manages a per-group list stored in `data/badwords.json`
- Event handler auto-deletes messages matching any bad word in the active group's list

### 2I — Nickname & Group Image Locks
- `nicknameLocks.js`: multi-level lock (group-wide + per-user); enforces every 60s; stores lock state in `data/nicknameLocks.json`
- `nameLocks.js`: group name rotation lock; persists in `data/nameLocks.json`
- `groupImgLocks.js`: group image lock; persists in `data/groupImgLocks.json`
- All use atomic writes via `utils/atomicWrite.js`

### 2J — Two-Process Watchdog Architecture
- `Main.js` runs as the parent; spawns `ZAO.js` and `INSTA.js` as child processes
- If either child crashes, Main.js auto-restarts it with exponential backoff
- Web panel stays alive even if the bot is restarting
- Restart count and history persisted in `data/restart-stats.json` + `data/restart-history.json`
- `data/first-start.json` written once on very first boot — used to compute total system uptime

---

## PART 3 — WEB PANEL FEATURES (`webpanel/zao-server.js`)

Panel runs on port 5000 (Express SSR). Auth: session-cookie with `PANEL_PASSWORD` env var (default `SainxSain`). All routes behind `requireAuth` middleware.

### Facebook Bot Tabs (13 tabs)

| Tab | Route | Features |
|-----|-------|---------|
| الرئيسية (Status) | `/status` | Bot online/offline badge, active tier, MQTT status, message counter, restart count, last 3 restarts with timestamps, total system uptime from `first-start.json`, process uptime |
| السجلات (Logs) | `/logs` | Real-time log stream (SSE), filterable by level (info/warn/error), last N lines, ANSI color stripping, search box |
| الإعدادات (Settings) | `/settings` | Edit all fields in `ZAO-SETTINGS.json` via form: bot name, prefix, admin IDs, language, humanTyping config, mqttHealthCheck config, autoLock, reactUnsend, whiteListMode, whiteListModeThread, commandDisabled array |
| الأوامر (Commands) | `/commands` | List all loaded commands: name, category, permission level, cooldown, aliases. Toggle enable/disable per command (updates `commandDisabled` in settings). |
| المجموعات (Groups) | `/groups` | List all active groups from `global.data.allThreadID`: name, thread ID, member count. Search/filter. Send a message to any group directly from panel. |
| الأدمن (Admins) | `/admins` | Manage `ADMINBOT` and `adminBot` arrays: add/remove admin UIDs, see current list. |
| الكوكيز (Cookies) | `/cookies` | View/upload/download Facebook AppState for each tier (1–5). Shows file size, last modified, validity indicator. Upload new cookies as JSON. Download current cookies. Set `tierLimit`. |
| الذاكرة (DB) | `/db` | Browse SQLite tables (if Sequelize mode active): users, threads, currencies. Search by ID. Export table as JSON. |
| الحماية (Security) | `/security` | View live state of: autoLock (toggle + current lock status), badwords list per group, whitelist mode toggle, rate limiter stats. |
| الكنيات (Nicknames) | `/nicknames` | View/manage nickname lock state across all groups. See which groups have active locks, what templates are set. Clear locks per group. |
| الديف هب (DevHub) | `/devhub` | AI-powered development assistant with 5 agents (described in Section 4). |
| السمارت ديبلوي (Smart Deploy) | `/smart-deploy` | Version snapshots: create/restore/compare snapshots of key bot files. View diff between snapshot and current. |
| التيار (Tier Settings) | `/tier` | Set active tier, view tier file status (uploaded / empty placeholder), upload tier files. |

### Instagram Sub-Panel (4 pages, at `/insta/*`)

| Page | Route | Features |
|------|-------|---------|
| نظرة عامة (Overview) | `/insta` | Instagram bot online/offline, session age, message count, reconnect status |
| المحادثات (Threads) | `/insta/threads` | List active Instagram threads: name, ID, last message time. Send a message to any thread. |
| الأوامر (Commands) | `/insta/commands` | Same as Facebook commands tab but for Instagram command set. |
| الإعدادات (Settings) | `/insta/settings` | Username/password input (triggers INSTA.js login), prefix, admin IDs, rate limit config. |

---

## PART 4 — DEVHUB AI AGENTS (`webpanel/zao-devhub.js`)

5 specialized AI agents powered by OpenRouter (configured in `devhub-openrouter.json`):

| Agent | Role |
|-------|------|
| **مطور الأوامر** (Command Developer) | Write or modify bot commands. Takes a description → outputs a complete `module.exports.config + run` block. |
| **محلل الأخطاء** (Error Analyzer) | Paste an error/stack trace → explains the cause and provides a fix. |
| **مراجع الكود** (Code Reviewer) | Paste code → gets a security/quality review with improvement suggestions. |
| **مولّد الإعدادات** (Settings Generator) | Describe desired bot behavior → generates the matching `ZAO-SETTINGS.json` block. |
| **المساعد العام** (General Assistant) | Free-form questions about the bot's architecture, commands, or deployment. |

---

## PART 5 — KEY CONFIGURATION (ZAO-SETTINGS.json)

Implement these settings sections in any bot that wants to match ZAO's feature set:

```json
{
  "language": "en",
  "adminOnly": false,
  "humanTyping": {
    "enable": true,
    "minDelay": 800,
    "maxDelay": 4200,
    "charsPerSecond": 12,
    "jitterPercent": 30,
    "nightModeMultiplier": 2.2,
    "thinkingPauseChance": 0.18,
    "thinkingPauseMs": 1800
  },
  "mqttHealthCheck": {
    "enable": true,
    "silentTimeoutMinutes": 10,
    "checkIntervalMinMinutes": 2,
    "checkIntervalMaxMinutes": 5,
    "maxRestarts": 5,
    "backoffMultiplier": 1.5,
    "maxBackoffMinutes": 15,
    "notifyAdmins": true
  },
  "autoLock": {
    "enable": true,
    "maxCommands": 15,
    "windowSeconds": 30,
    "unlockAfterMinutes": 10,
    "notifyAdmins": true
  },
  "reactUnsend": {
    "enable": true,
    "onlyAdmin": true,
    "emojis": ["😡", "😠"]
  },
  "whiteListMode": { "enable": false, "whiteListIds": [] },
  "whiteListModeThread": { "enable": false, "whiteListThreadIds": [] },
  "commandDisabled": [],
  "notiWhenListenMqttError": {
    "minIntervalMinutes": 10,
    "telegram": { "enable": false, "botToken": "", "chatId": "" },
    "discordHook": { "enable": false, "webhookUrl": "" }
  },
  "tierLimit": 1,
  "BOTNAME": "ZAO",
  "PREFIX": ".",
  "ADMINBOT": [],
  "adminBot": []
}
```

---

## PART 6 — DATA FILES LAYOUT

```
data/
  ban.json              — { [threadID]: [uid, uid, ...] }
  warn.json             — { [threadID]: { [uid]: { count, reasons[] } } }
  ai-users.json         — { users: [{ ids: [uid], name, note }] }
  nameLocks.json        — group name lock state
  nicknameLocks.json    — nickname lock state (group + user level)
  groupImgLocks.json    — group image lock state
  badwords.json         — { [threadID]: [word, word, ...] }
  autoinvite_settings.json — { [threadID]: { enabled: bool } }
  protectData.json      — { [threadID]: { [uid]: nickname } }
  restart-stats.json    — { count: N }
  restart-history.json  — last 3 restart timestamps
  first-start.json      — { timestamp: ISO } — written once, never overwritten
  active-tier.json      — { tier: N }
  labyrinth-*.json      — E2EE ratchet state per thread
backups/
  ZAO-STATE-YYYY-MM-DD-HH-MM.json — timestamped cookie snapshots
panel/
  smart-versions.json   — array of version snapshot objects
```

---

## PART 7 — IMPLEMENTATION NOTES

1. **Atomic writes**: Always use atomic write (write-to-temp + rename) for any JSON state file the bot reads and writes concurrently. A plain `writeFileSync` on a file that's being read by another async call can produce torn/empty JSON.

2. **Single-loop motors**: Each per-thread loop (name rotation, image rotation) must track whether a loop is already running for that thread (e.g. `_activeLoops: Map<threadID, handle>`) to prevent duplicates after restarts or reconnects.

3. **`api` reference freshness**: After MQTT reconnect, the `api` object is replaced. Always prefer `global._botApi || api` (or `api || global._botApi` when the caller passes a fresh api) to avoid stale references.

4. **Tier fallback**: Maintain an ordered list of tier cookie files (ZAO-STATE.json, ZAO-STATE2.json … ZAO-STATE5.json). On login failure, try next tier. On exhaustion, wait N minutes and retry from tier 1 — do not exit.

5. **Two-process design**: Run the web panel and the bot as separate processes. The panel process (Main.js) spawns the bot (ZAO.js) as a child. This keeps the admin dashboard accessible even when the bot is crashing/restarting.

6. **Command loading**: `execSync('npm install', { timeout: 90000 })` inside the command/event loader paths — set the timeout explicitly. Without it, a slow npm registry can hang the entire bot boot indefinitely.

7. **E2EE wire format**: Prefix encrypted messages with a recognizable emoji+token (`🔐ZAO|`) so the receiver can distinguish encrypted from plaintext before attempting Base64 decode.
