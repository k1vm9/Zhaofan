"use strict";
/**
 * ZAO-ENGINE — Rate Limiter
 * Source: David's rateLimit.js — simple sliding-window rate limiter.
 * 100% stable — never throws. Cleanup interval uses .unref() so it
 * never keeps the process alive by itself.
 */

const store = new Map();

function check(key, max, windowMs) {
  try {
    const now = Date.now();
    if (!store.has(key)) store.set(key, { e: [], w: false });
    const entry = store.get(key);
    entry.e = entry.e.filter(t => now - t < windowMs);
    entry.e.push(now);
    return { exceeded: entry.e.length > max, count: entry.e.length, warned: entry.w };
  } catch (_) { return { exceeded: false, count: 0, warned: false }; }
}

function setWarned(key) {
  try { if (store.has(key)) store.get(key).w = true; } catch (_) {}
}

function reset(key) { store.delete(key); }

function getCount(key, windowMs) {
  try {
    if (!store.has(key)) return 0;
    const now = Date.now();
    return store.get(key).e.filter(t => now - t < (windowMs || 60000)).length;
  } catch (_) { return 0; }
}

const _cleanup = setInterval(() => {
  try {
    const n = Date.now();
    for (const [k, v] of store) {
      v.e = v.e.filter(t => n - t < 300000);
      if (!v.e.length) store.delete(k);
    }
  } catch (_) {}
}, 5 * 60 * 1000);
if (_cleanup?.unref) _cleanup.unref();

module.exports = { check, setWarned, reset, getCount };
